# da-components

A focused component foundation for Elm applications using `elm/html` and CSS.
It provides consistent structure, interaction, and styling while leaving application
state and business decisions in your app. Version 0.2.3 is a private source bundle,
not a published Elm registry package.

## The core

| Module | Purpose |
| --- | --- |
| `Da.Button` | Text/content/icon actions, submit buttons, navigation links, primary/secondary/quiet/danger variants, disabled and busy states |
| `Da.Card` | Composable header, title, description, content, and footer |
| `Da.Form` | Submission, grouped sections, action rows, linked error summaries, busy forms |
| `Da.Field` | Text/email/password/search/numeric drafts, textarea, native select, checkbox, switch, radio group, segmented values, range sliders |
| `Da.Dropdown` | Styled select-only dropdown, themed option list, controlled state, keyboard navigation and typeahead |
| `Da.Combobox` | Editable search, grouped/described options, explicit selection, loading/empty/error states |
| `Da.Layout` | Stack, wrapping row, adaptive grid, bounded container, separator, scoped compact density |
| `Da.Tabs` | Controlled panels, keyboard navigation, disabled items, scoped IDs, focus helper |
| `Da.Disclosure` | Native details/summary expansion |
| `Da.Feedback` | Persistent/actionable notices, warning tone, operation status, progress, measurement meters, empty states |
| `Da.Badge` | Compact state labels and counts |
| `Da.Activity` | Labeled busy indicators, with polite-status and inline variants |
| `Da.Toolbar` | Wrapping, labeled action groups with ordinary Tab order |
| `Da.Dialog` | Controlled native modal dialogs, titles, body/actions, initial focus and dismissal |
| `Da.Popover` | Anchored nonmodal surfaces for ordinary controls and content |
| `Da.Menu` | Anchored command menus, disabled actions, keyboard navigation and typeahead |
| `Da.FilePicker` | Labeled native file selection and file-drop interaction |
| `Da.FileList` | Compact filename/detail rows with shared ordering and caller-owned removal |
| `Da.Reorderable` | Caller-owned ordered items, move buttons, keyboard moves and pointer dragging |
| `Da.Theme` | Scoped light/dark/system themes and CSS variables |
| `Da.ThemeToggle` | Compact sun/moon/monitor button that cycles light, dark, and system modes |

This is deliberately a core. Forms, requests, routes, validation, persistence,
file processing, and application-specific workspaces remain in the consuming app.
Dialogs, popovers, and menus use a small opt-in browser adapter. The other
components need only Elm and CSS. See [workspace component contracts](docs/workspace-components.md)
for the new APIs, setup, ownership, and keyboard behavior.

## Development

Launch the preview with the pinned Nix development shell:

```sh
nix-shell --run 'just dev'
```

The shell supplies only Node.js 24 (including npm) and `just`. npm installs the
Elm compiler, formatter, and test runner at the versions in `package-lock.json`.
`just dev` installs missing dependencies, builds the catalog, and starts its
server. Bare `just` also launches the preview. Run `just setup` to reinstall
dependencies after changing the npm lockfile.

For an interactive shell, run `nix-shell`, then use `just dev` or the other recipes.
If you already use direnv with Nix support, run `direnv allow` once to enable the
included `.envrc`; the shell then loads when you enter the repository.
`nix develop` and `nix develop --command just dev` also work. Both Nix entry points
use the same package list and the nixpkgs revision pinned in `flake.lock`.

The standalone catalog runs at **http://127.0.0.1:3201**. `PORT` changes its port.
The server builds the current catalog on startup and watches Elm, CSS, and catalog
HTML. CSS changes refresh without losing form drafts; Elm and HTML changes reload
the page at the same scroll position. Failed builds keep the last successful
preview visible and show a build-error message until the source is fixed.
`just build` creates a static `dist/` directory. The library and catalog do not
require PDF Tools. The catalog opens in dark mode; use the theme button to compare
light and system modes.

After an agent changes this library, it must start or reuse the current dev preview,
leave it available, and provide its URL. This requirement is recorded in
[alchemy.md](alchemy.md#inv-change-preview-provide-a-preview-after-library-changes).

Use `just check` for the full non-browser checks, `just test` for Elm tests,
and `just fmt` to format Elm. The existing npm commands remain available without
Nix if you have Node 20 or newer and npm installed.

Browser checks require Python with Playwright and installed Chromium/Firefox:

```sh
python3 -m pip install -r scripts/requirements-browser.txt
python3 -m playwright install chromium firefox
npm run build
npm run test:browser
```

When a sandbox prevents binding a local HTTP port, the browser checks can load
the same built assets through Playwright routes instead:

```sh
python3 scripts/browser_test.py --browser firefox --local-assets
```

The default still checks Chromium and Firefox against an actual local server.
The routed mode is verification only; it does not start a user-facing preview.
`--scope workspace` limits the run to the additions. `--no-screenshots` retains
behavior, layout, and contrast checks while skipping captures; the results record
whether screenshots were produced.

The browser test starts its own temporary local server and writes screenshots and
results to `artifacts/`. It verifies behavior and measured theme-token contrast;
it does not establish full accessibility conformance or replace screen-reader testing.
`npm run check` also compiles all modules in a fresh app installed from the tarball.
The included GitHub Actions workflow runs these checks when this project is hosted.

For a repeatable visual feedback loop, keep `just dev` running, then use Python
Playwright to capture the catalog before and after an edit:

```sh
just visual before
# Edit the components and let the dev server rebuild.
just visual after
```

Open `artifacts/visual/after/index.html` to compare matching screenshots side by
side. The captures include each component, the composed estimate example, light
and dark themes, desktop and narrow viewports, and 200% text.
The preferences controls also get close-up captures with selection on and off,
keyboard focus, disabled inputs, and forced colors at desktop and mobile sizes.
Inspect spacing, hierarchy, shapes, and surface separation, adjust the source,
and capture again until the result is satisfactory. `measurements.json` records overflow, measured
theme-token contrast, and page errors; those checks complement visual inspection.
Use `python3 scripts/visual_review.py --label after --compare before --url
http://127.0.0.1:3201` to select a different preview address or comparison label.

## Use in an existing Elm app

Create a versioned tarball from this repository:

```sh
npm pack
```

Install that tarball in the application's frontend directory:

```sh
npm install /path/to/da-components/da-components-0.2.3.tgz
```

Add the installed source directory to the application's `elm.json`:

```json
"source-directories": ["elm", "node_modules/da-components/src"]
```

The source-directory path is relative to the app's `elm.json`. If your code lives in
`src`, retain that directory instead of `elm`. npm distributes the source and CSS;
**it does not install Elm dependencies**. The complete core uses `elm/core`,
`elm/html`, `elm/browser`, `elm/json`, and `elm/file`; use `elm install` in the app to add any
missing direct dependencies. The exact tested versions are in
[docs/elm-dependencies.json](docs/elm-dependencies.json).

Copy `node_modules/da-components/styles/da-components.css` into your application's
build assets and load it once. Wrap the component tree in a themed root:

```elm
import Da.Button as Button
import Da.Theme as Theme

view model =
    Theme.root Theme.System []
        [ Button.view [] Button.primary "Save" Save ]
```

Include this CSS in your existing asset hash/versioning. Ship the matching Elm
source and stylesheet together, and upgrade the tarball explicitly. Never edit
the installed copy in `node_modules`; improve the library and release a new bundle.

## Composition and state ownership

Components return `Html msg` and emit the caller's messages. There is no global
component model, app port, storage key, or dependency on an app's API. The optional
overlay adapter performs DOM lifecycle and focus work for Dialog, Popover, and Menu;
install it explicitly on each owning themed root and dispose it when unmounting.
The application owns draft values, validation, submit eligibility, async requests,
retry actions, routing, theme persistence, and notification timing.

```elm
import Da.Card as Card
import Da.Field as Field
import Da.Form as Form

profileForm model =
    Card.view []
        [ Card.header []
            [ Card.title Card.H2 "Profile"
            , Card.description "Your account details."
            ]
        , Card.content []
            [ Form.view [] { onSubmit = Save, busy = model.saving }
                [ Field.input [] (Field.config "profile-name" "Name")
                    { value = model.name
                    , onInput = NameChanged
                    , kind = Field.Text
                    }
                , Form.actions []
                    [ Button.submit [] Button.primary "Save settings" ]
                ]
            ]
        ]
```

Keep numeric values as raw strings while editing. `Field.Decimal` and
`Field.Integer` use a text input with an appropriate input mode, retaining drafts
such as `4.`, `-`, or an empty value. Parse in your app and provide `Config.error`.
Show validation at the appropriate time for your workflow; the library does not
decide when a user has finished editing. `Form.view` disables browser constraint
validation so your app's visible errors and submission rules remain authoritative.
Guard submission in `update`, including during an in-flight request.

## IDs, attributes, and keyboard behavior

Use document-unique field and tab-group IDs, including when forms repeat. Keep tab
IDs unique within their group and option values unique within radio/select groups.
Help and error IDs are derived from the caller's field ID. Error-summary targets
must be actual field IDs. Radio groups use that ID as their native group name.

Attribute lists are extension points for `name`, autocomplete, placeholder,
data attributes, and app-specific event handlers. The component's own class,
controlled value, input type, disabled state, IDs, and required accessibility
attributes are reserved. They are applied after extension attributes. Use an
outer wrapper, a stable app ID, and CSS variables for styling instead of replacing
the component class. Controls own their principal click/input/change handlers.

Action buttons explicitly use `type="button"`; `Button.submit` uses `type="submit"`.
`Button.Appearance.className` adds application layout or test hooks while retaining
the shared component and variant classes. Start from `Button.defaults`, `primary`,
`quiet`, or `danger` and update the record; version 0.2 adds this field to explicit
appearance records. Keep component appearance in the shared stylesheet. An app
can place its layout stylesheet in a lower CSS cascade layer so legacy selectors
do not override the common controls.
Use `Field.selectContent` for native `option` and `optgroup` content when choices
need grouping. It retains the field's controlled value, label, and validation.
`Button.link` remains an anchor and supports browser navigation and opening in a
new tab. Card titles require an explicit heading level. Native selects, radios,
checkboxes, and disclosures retain their browser keyboard interactions.

Tabs are controlled. Handle selection and run the provided focus command:

```elm
TabChanged selected ->
    ( { model | selected = selected }
    , Tabs.focus "settings-tabs" selected (\_ -> NoOp)
    )
```

Use the same group ID in `Tabs.view`. Arrow keys wrap and skip disabled tabs;
Home/End select the first/last available item. All panels stay mounted and inactive
panels use `hidden`, preserving browser draft state. If selection becomes invalid,
the view uses the first enabled tab; reconcile that fallback in app state when
changing tab availability. Handle focus failures if your workflow requires recovery.

## Styled dropdowns

Use `Da.Dropdown` when both the field and its open menu should match the library.
The Plan control in the catalog demonstrates it. `Field.select` remains available
for applications that prefer the browser's native picker.

Store `Dropdown.initial` in a separate model field for each dropdown and handle
every `Dropdown.Change`. The component reuses `Field.Config` for its label, help,
validation, orientation, and disabled state:

```elm
planControl model =
    { value = model.plan
    , state = model.planDropdown
    , options =
        [ { value = "personal", label = "Personal", disabled = False }
        , { value = "team", label = "Team", disabled = False }
        ]
    , onChange = PlanChanged
    }

planConfig =
    Field.config "plan" "Plan"

-- View
Dropdown.view [] planConfig (planControl model)

-- Subscriptions: batch these for multiple instances.
Dropdown.subscriptions planConfig (planControl model)

-- Update
PlanChanged change ->
    let
        next =
            { model | plan = change.value, planDropdown = change.state }
    in
    ( next, Dropdown.reveal "plan" (planControl next) (\_ -> NoOp) )
```

Arrow keys, Home/End, and Page Up/Down explore enabled options; typing finds labels.
Navigation preserves the current value until Enter, Space, Tab, blur, an outside
click, or an option click commits the active option. Escape and clicking the
trigger again cancel exploration. Tab continues to the next control. DOM focus
stays on the trigger and `aria-activedescendant` identifies the active option;
`reveal` keeps that option visible while navigating a scrollable menu. The selected
value has a checkmark, and keyboard activity has an outline. Empty and entirely
disabled option lists disable the trigger.

IDs must be document-unique and option values unique within a list. Reset popup
state to `Dropdown.initial` when resetting a form or replacing its options.
Pass the same configuration to the view and subscriptions, including its disabled
state. The app owns validation, the selected value, popup state, and form submission;
use the controlled value when submitting. This custom dropdown does not add a
native form-data entry. Public browser attributes and keyboard behavior follow the
[WAI select-only combobox pattern](https://www.w3.org/WAI/ARIA/apg/patterns/combobox/examples/combobox-select-only/);
browser checks do not replace assistive-technology testing.

## Themes and layouts

Use `Da.ThemeToggle` for a compact rounded icon button. It shows the current mode
and requests the next one in the order light → dark → system → light:

```elm
import Da.ThemeToggle as ThemeToggle

ThemeToggle.view []
    { mode = model.theme
    , label = "Light theme. Switch to dark theme"
    , onChange = ThemeChanged
    }
```

Handle `ThemeChanged mode` in your app and pass that mode to both `Theme.root`
and the toggle. Supply a localized accessible label that updates with the mode;
the label also serves as the button's tooltip. Enter and Space activate the native
button without submitting forms. Add `Html.Attributes.disabled True` to the
attribute list for an unavailable control. Selection, startup choice, and
persistence belong to the app. The toggle shares button focus and motion defaults.

Set a brand accent with one hex color. The helper chooses black or white button
text for contrast and works in light, dark, and system modes:

```elm
Theme.root Theme.System
    (Theme.accent "#6750a4" ++ [ Html.Attributes.id "my-app" ])
    [ applicationView ]
```

`Theme.accent` accepts `#RGB` and `#RRGGBB` (case-insensitive). Invalid values keep
the default theme colors. The caller owns the chosen color and persistence.
The catalog's Theme section includes a live color picker and a reset button.
Use a separate accent per theme if your brand needs it.

Soft accent fills and focus colors derive from the accent. Selected tabs use a
neutral filled surface and stronger text weight, with `aria-selected` for assistive
technology; switches move their thumb. Controls share a rounded rectangular shape; cards use a larger
corner radius. Defaults use neutral surfaces, sparse pink accents, and readable
16px control text. Primary buttons use solid accent fills with shade changes on
hover and press; their labels stay free of underlines. Secondary buttons use
neutral fills with muted labels and neutral hover feedback. Font sizing remains
relative to the document.

Text fields, textareas, and native selects use a shared rounded, neutral panel
with the label and help inside it. Values have larger type, with extra emphasis
for numeric drafts. Hover outlines stay subtle; keyboard focus outlines the whole
panel, and errors retain their linked message and visible border. Horizontal and
responsive orientations still place the label beside the value when appropriate.

For CSS-only consumers, set `--da-accent` and a contrasting `--da-on-accent` on the
same `.da-ui` root. Put overrides after the library stylesheet; use a selector
that also covers theme attributes. The Elm helper supplies inline tokens and owns the root's style attribute. Use your stylesheet for spacing and
other root styling. To supply explicit inline tokens, use
`Html.Attributes.attribute "style"` after the helper with the complete declaration
string; it replaces the helper's declarations. Elm's `Html.Attributes.style`
does not set CSS custom properties in browsers.

```css
#my-app[data-da-theme] {
  --da-accent: #6750a4;
  --da-on-accent: #ffffff;
}
```

Custom colors still need application-level contrast checks, including disabled
states and surrounding surfaces. The helper guarantees the foreground choice
for its solid accent, not arbitrary CSS overrides or every application state.

Styles are scoped beneath `.da-ui`; they do not change `body`, document overflow,
global headings, unrelated buttons, or startup rendering. The catalog has a
separate stylesheet that is not part of the component bundle. Wrap overlays in the
same theme scope if you add application-owned overlays later.

```css
#my-app {
  --da-space: 1.25rem;
  --da-grid-min: 20rem;
  --da-card-padding: 1.5rem;
}
```

Public tokens include background/surface/surface-muted, text/muted, border/divider,
accent/on-accent/accent-soft, danger/focus, radius, space, control-height, content-width,
grid-min, and card-padding. The default focus and soft accent tokens use CSS `color-mix()` (supported by current Chromium, Firefox, and Safari). Changing colors requires rechecking contrast.
`Theme.System` follows `prefers-color-scheme`; app storage and initialization stay
outside the library.

Fields default to vertical layout. `Field.Responsive` uses the form body's
container width to align labels and controls when there is room; it remains
vertical outside a form container. `Field.Horizontal` explicitly uses two columns.
For workspace controls, apply `Layout.compact` to an existing region and use
`Field.present` with `Compact`, `Inline`, or `Embedded`. This keeps compact search,
toolbar selectors, and composer textareas consistent without changing the form
defaults or field configurations. See the [presentation contracts](docs/workspace-components.md#form-and-workspace-presentations)
and interactive Compact workspace example in the catalog.
Rows wrap, grids adapt to their container, and components avoid document scrolling
assumptions. Defaults include visible focus, reduced motion, logical-direction
spacing, and a forced-colors fallback for switches.

## Motion

Motion is built in and opinionated, with fixed timings and a shared smooth ease-out
curve for interactions and reveals. There are no animation props, opt-in attributes, or public motion tokens.
Buttons use 150ms color transitions and a 100ms, 1px press. Field hover borders
transition over 150ms; keyboard focus and new error indicators appear immediately.
Switch thumbs and tracks transition over 180ms, including in RTL. Tabs use 150ms
selection transitions and content reveals. Disclosures rotate their chevron over
180ms and reveal content over 150ms on opening; closing stays immediate.

Notices and operation status fade in with a gentle 6px rise over 320ms when
inserted. Updating their text does not replay the entrance. Focused content is
immediately fully opaque and still. Cards, layouts, and empty states stay still.
Checkboxes and radios retain their native browser feedback. Progress uses a themed
track whose fill glides to new values over 480ms and retargets from its current
position on rapid updates. Indeterminate progress sweeps smoothly with an ease-in-out
curve over 1800ms; reduced motion shows a static segment. Progress keeps its native
accessible element, immediate clamped value, and label, and uses the native visual
in forced colors. Fill and sweep follow RTL direction automatically. The catalog
includes controls to repeat notice insertion, update a visible message, and replay
an upload without shifting the surrounding examples.

`prefers-reduced-motion: reduce` removes all library transitions, press movement,
and reveal animations automatically. Hover styling applies only on devices that
support hover. Disabled and busy controls receive no press motion. Input, selection,
focus, hidden panels, and accessibility state never wait for animation; application
state and effects remain with the caller.

## Design basis and expansion

[docs/research.md](docs/research.md) records the structural references and why this
core was selected. shadcn supplies component anatomy and conventional interaction
examples; its visual styling and React implementation are not copied.

Add components when they solve a repeated task, can expose a small app-independent
API, and have examples for their meaningful states. Interaction-heavy additions
need keyboard/focus and failure contracts before joining the stable core. Maintain
this library's [invariants](alchemy.md) alongside those contracts.


For model pickers and other controls where opening should start a new search,
initialize each instance with `Combobox.searchInitial`. It opens with an empty
query and matches noncontiguous characters, ignoring case and query whitespace,
against labels and option values. Escape, Tab, blur, and outside clicks restore
the committed label. Selecting an option retains this search mode, and clicking
the focused, closed input starts another empty search. `Combobox.initial` retains
its existing selected-label and substring-search behavior.
