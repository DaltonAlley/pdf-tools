// Optional DOM lifecycle for Da.Dialog, Da.Popover, and Da.Menu.
// Elm owns open/closed state. This adapter emits da-close requests, never app data.
const installations = new WeakMap();

export function install(root) {
  if (!(root instanceof Element)) throw new TypeError('DA install expects a themed root element');
  if (installations.has(root)) return installations.get(root);
  const abort = new AbortController();
  const records = new Map();
  const menuEdges = new WeakMap();
  const options = { signal: abort.signal };
  const owns = node => {
    for (let ancestor = node.parentElement; ancestor; ancestor = ancestor.parentElement) {
      if (installations.has(ancestor)) return ancestor === root;
    }
    return root.contains(node);
  };
  let frame;
  let disposed = false;
  const shown = node => node.dataset.daOverlay === 'dialog' ? node.open : node.matches(':popover-open');
  const visible = node => node?.isConnected && node.getClientRects().length && !node.closest('[inert], [hidden]');
  const focusable = node => [...node.querySelectorAll('button:not(:disabled), input:not(:disabled), select:not(:disabled), textarea:not(:disabled), a[href], [tabindex="0"]')].filter(visible);
  const anchorFor = node => {
    const anchor = document.getElementById(node.dataset.daAnchor);
    return anchor && root.contains(anchor) ? anchor : null;
  };
  const top = () => [...records.values()].filter(record => record.open && record.node.isConnected).at(-1);

  function requestClose(record, reason, restore = true) {
    if (!record || record.requested || (record.node.dataset.daOverlay === 'dialog' && record.node.dataset.daDismissible === 'false')) return;
    record.requested = true;
    record.restore = restore;
    record.node.dispatchEvent(new CustomEvent('da-close', { detail: { reason } }));
  }

  function position(record) {
    const node = record.node;
    const anchor = anchorFor(node);
    if (!record.open || node.dataset.daOverlay === 'dialog' || !anchor || !shown(node)) return;
    const viewport = window.visualViewport;
    const left = viewport?.offsetLeft ?? 0;
    const top = viewport?.offsetTop ?? 0;
    const width = viewport?.width ?? innerWidth;
    const height = viewport?.height ?? innerHeight;
    const gap = 8;
    node.style.maxWidth = `${Math.max(0, width - gap * 2)}px`;
    const bounds = anchor.getBoundingClientRect();
    const below = Math.max(0, top + height - bounds.bottom - gap * 2);
    const above = Math.max(0, bounds.top - top - gap * 2);
    node.style.maxHeight = `${Math.max(below, above)}px`;
    const size = node.getBoundingClientRect();
    const useAbove = size.height > below && above > below;
    node.style.maxHeight = `${useAbove ? above : below}px`;
    const actual = node.getBoundingClientRect();
    const start = getComputedStyle(anchor).direction === 'rtl' ? bounds.right - actual.width : bounds.left;
    node.style.left = `${Math.max(left + gap, Math.min(start, left + width - actual.width - gap))}px`;
    node.style.top = `${Math.max(top + gap, useAbove ? bounds.top - actual.height - gap : bounds.bottom + gap)}px`;
  }

  function schedulePosition() {
    if (frame || disposed) return;
    frame = requestAnimationFrame(() => {
      frame = undefined;
      for (const record of records.values()) position(record);
    });
  }

  function close(record, restore = record.restore) {
    record.open = false;
    record.resize?.disconnect();
    const active = document.activeElement;
    if (shown(record.node)) {
      if (record.node.dataset.daOverlay === 'dialog') record.node.close();
      else record.node.hidePopover();
    }
    if ((restore || record.node.contains(active)) && visible(record.opener) && (record.node.contains(active) || active === document.body)) {
      record.opener.focus({ preventScroll: true });
    }
  }

  function open(record) {
    const node = record.node;
    const kind = node.dataset.daOverlay;
    if (kind !== 'dialog' && !anchorFor(node)) {
      node.dispatchEvent(new CustomEvent('da-overlay-error', { detail: { message: 'Missing overlay anchor' } }));
      requestClose(record, 'missing-anchor', false);
      return;
    }
    record.opener = document.activeElement;
    record.restore = true;
    record.requested = false;
    record.open = true;
    // Move the newly opened surface to the end of our dismissal stack.
    records.delete(node);
    records.set(node, record);
    try {
      if (kind === 'dialog') node.showModal();
      else node.showPopover();
    } catch (error) {
      record.open = false;
      node.dispatchEvent(new CustomEvent('da-overlay-error', { detail: { message: error.message } }));
      requestClose(record, 'open-failed', false);
      return;
    }
    position(record);
    record.resize = new ResizeObserver(schedulePosition);
    record.resize.observe(node);
    const anchor = anchorFor(node);
    if (anchor) record.resize.observe(anchor);
    const requested = document.getElementById(node.dataset.daInitialFocus);
    const items = focusable(node);
    const edge = anchor && menuEdges.get(anchor);
    if (anchor) menuEdges.delete(anchor);
    const target = requested && node.contains(requested) && visible(requested)
      ? requested : kind === 'dialog'
        ? node.querySelector('h2') : edge === 'last' ? items.at(-1) : items[0];
    (target ?? node).focus({ preventScroll: true });
    // Showing a popover changes native sequential focus order around its invoker.
    // Our explicit anchor is also used for Escape and Tab return behavior.
  }

  function reconcile() {
    if (disposed) return;
    const nodes = new Set([...root.querySelectorAll('[data-da-overlay]')].filter(owns));
    for (const [node, record] of records) {
      if (!nodes.has(node)) {
        record.controller.abort();
        close(record);
        records.delete(node);
      }
    }
    for (const node of nodes) {
      let record = records.get(node);
      if (!record) {
        record = { node, open: false, requested: false, restore: true, opener: null, prefix: '', typedAt: 0, controller: new AbortController() };
        records.set(node, record);
        node.addEventListener('cancel', event => {
          event.preventDefault();
          requestClose(record, 'escape');
        }, { signal: record.controller.signal });
        node.addEventListener('close', () => {
          if (record.open && node.dataset.daOpen === 'true') requestClose(record, 'native-close');
        }, { signal: record.controller.signal });
        node.addEventListener('toggle', event => {
          if (event.newState === 'closed' && record.open && node.dataset.daOpen === 'true') requestClose(record, 'native-close');
        }, { signal: record.controller.signal });
      }
      const wanted = node.dataset.daOpen === 'true';
      if (wanted && !record.open && !record.requested) open(record);
      else if (!wanted && record.open) close(record);
      if (!wanted) record.requested = false;
      if (record.open && node.dataset.daOverlay !== 'dialog' && !anchorFor(node)) requestClose(record, 'missing-anchor');
    }
    schedulePosition();
  }

  const observer = new MutationObserver(reconcile);
  observer.observe(root, { subtree: true, childList: true, attributes: true, attributeFilter: ['data-da-open', 'data-da-anchor', 'data-da-initial-focus', 'data-da-dismissible', 'disabled', 'hidden'] });
  document.addEventListener('pointerdown', event => {
    const record = top();
    if (!record || record.node.dataset.daOverlay === 'dialog') return;
    const path = event.composedPath();
    if (!path.includes(record.node) && !path.includes(anchorFor(record.node))) requestClose(record, 'outside', false);
  }, { ...options, capture: true });
  document.addEventListener('focusin', event => {
    const record = top();
    if (!record || record.node.dataset.daOverlay === 'dialog') return;
    if (!record.node.contains(event.target) && event.target !== anchorFor(record.node)) requestClose(record, 'focus-left', false);
  }, options);
  document.addEventListener('keydown', event => {
    if (event.isComposing || event.defaultPrevented) return;
    const record = top();
    if (event.key === 'Escape' && record && (record.node.contains(event.target) || root.contains(event.target))) {
      event.preventDefault();
      event.stopPropagation();
      requestClose(record, 'escape');
      return;
    }
    if (!record?.open || record.node.dataset.daOverlay !== 'menu' || !record.node.contains(event.target)) {
      if (root.contains(event.target) && event.target.matches('[aria-haspopup="menu"]') && ['ArrowDown', 'ArrowUp'].includes(event.key)) {
        event.preventDefault();
        menuEdges.set(event.target, event.key === 'ArrowUp' ? 'last' : 'first');
        event.target.click();
      }
      return;
    }
    const items = [...record.node.querySelectorAll('[role="menuitem"]:not(:disabled)')].filter(visible);
    const index = items.indexOf(document.activeElement);
    let next;
    if (event.key === 'ArrowDown') next = items[(index + 1) % items.length];
    else if (event.key === 'ArrowUp') next = items[(index - 1 + items.length) % items.length];
    else if (event.key === 'Home') next = items[0];
    else if (event.key === 'End') next = items.at(-1);
    else if (event.key === 'Tab') {
      event.preventDefault();
      const anchor = anchorFor(record.node);
      const candidates = focusable(document.body).filter(node => !node.closest('[data-da-overlay]'));
      const at = candidates.indexOf(anchor);
      const destination = candidates[at + (event.shiftKey ? -1 : 1)];
      requestClose(record, 'tab', false);
      (destination ?? anchor)?.focus();
      return;
    } else if (event.key.length === 1 && event.key !== ' ' && !event.ctrlKey && !event.metaKey && !event.altKey) {
      record.prefix = event.timeStamp - record.typedAt < 700 ? record.prefix + event.key.toLowerCase() : event.key.toLowerCase();
      record.typedAt = event.timeStamp;
      const prefix = [...record.prefix].every(character => character === record.prefix[0]) ? record.prefix[0] : record.prefix;
      const rotated = [...items.slice(index + 1), ...items.slice(0, index + 1)];
      next = rotated.find(item => item.textContent.trim().toLowerCase().startsWith(prefix));
    }
    if (next) {
      event.preventDefault();
      next.focus();
    }
  }, options);
  document.addEventListener('scroll', schedulePosition, { ...options, capture: true });
  window.addEventListener('resize', schedulePosition, options);
  window.visualViewport?.addEventListener('resize', schedulePosition, options);
  window.visualViewport?.addEventListener('scroll', schedulePosition, options);
  const dispose = () => {
    if (disposed) return;
    disposed = true;
    observer.disconnect();
    abort.abort();
    cancelAnimationFrame(frame);
    for (const record of records.values()) {
      record.controller.abort();
      close(record, false);
    }
    records.clear();
    installations.delete(root);
    for (let ancestor = root.parentElement; ancestor; ancestor = ancestor.parentElement) installations.get(ancestor)?.reconcile();
  };
  dispose.reconcile = reconcile;
  installations.set(root, dispose);
  for (let ancestor = root.parentElement; ancestor; ancestor = ancestor.parentElement) installations.get(ancestor)?.reconcile();
  reconcile();
  return dispose;
}
