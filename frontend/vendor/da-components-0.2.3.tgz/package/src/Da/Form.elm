module Da.Form exposing (view, section, actions, errors)

{-| Form composition. The application owns drafts, validation, touched state,
and submission policy. A busy form disables its native controls. Always guard
the submit action in update as well: this is presentation, not authorization.

@docs view, section, actions, errors

-}

import Html exposing (Html)
import Html.Attributes as A
import Html.Events as E


view : List (Html.Attribute msg) -> { onSubmit : msg, busy : Bool } -> List (Html msg) -> Html msg
view attrs config children =
    Html.form
        (attrs
            ++ [ A.class "da-form"
               , E.onSubmit config.onSubmit
               , A.novalidate True
               , A.attribute "aria-busy"
                    (if config.busy then
                        "true"

                     else
                        "false"
                    )
               ]
        )
        [ Html.fieldset [ A.class "da-form__body", A.disabled config.busy ] children ]


section : List (Html.Attribute msg) -> { legend : String, description : Maybe String } -> List (Html msg) -> Html msg
section attrs config children =
    Html.fieldset (attrs ++ [ A.class "da-form__section" ])
        (Html.legend [ A.class "da-form__legend" ] [ Html.text config.legend ]
            :: (case config.description of
                    Just help ->
                        [ Html.p [ A.class "da-form__description" ] [ Html.text help ] ]

                    Nothing ->
                        []
               )
            ++ children
        )


actions : List (Html.Attribute msg) -> List (Html msg) -> Html msg
actions attrs children =
    Html.div (attrs ++ [ A.class "da-form__actions" ]) children


{-| Render only after validation should be announced (usually on submission).
Each link targets a caller-provided field ID. An empty list renders nothing.
-}
errors : List (Html.Attribute msg) -> { id : String, title : String, errors : List { fieldId : String, message : String } } -> Html msg
errors attrs config =
    if List.isEmpty config.errors then
        Html.text ""

    else
        Html.div
            (attrs ++ [ A.class "da-form__errors", A.attribute "role" "alert", A.attribute "aria-labelledby" (config.id ++ "-title") ])
            [ Html.p [ A.id (config.id ++ "-title") ] [ Html.strong [] [ Html.text config.title ] ]
            , Html.ul [] (List.map (\error -> Html.li [] [ Html.a [ A.href ("#" ++ error.fieldId) ] [ Html.text error.message ] ]) config.errors)
            ]
