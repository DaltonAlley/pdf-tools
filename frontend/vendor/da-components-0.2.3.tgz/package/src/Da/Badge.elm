module Da.Badge exposing (view)

{-| Compact text labels and counts. Badges are not interactive and do not create
live regions. State must be expressed in the label, not only by its color.

@docs view

-}

import Da.Feedback as Feedback
import Html exposing (Html)
import Html.Attributes as A


view : List (Html.Attribute msg) -> Feedback.Tone -> String -> Html msg
view attrs tone label =
    Html.span
        (attrs
            ++ [ A.class
                    ("da-badge "
                        ++ (case tone of
                                Feedback.Neutral ->
                                    "da-badge--neutral"

                                Feedback.Success ->
                                    "da-badge--success"

                                Feedback.Warning ->
                                    "da-badge--warning"

                                Feedback.Error ->
                                    "da-badge--error"
                           )
                    )
               ]
        )
        [ Html.text label ]
