module Da.Activity exposing (view, indicator)

{-| Labeled indeterminate activity. Use view for a standalone polite status.
Use indicator inside an existing status region to avoid nested announcements.
Reduced motion renders a still indicator. The app owns activity and timing.

@docs view, indicator

-}

import Html exposing (Html)
import Html.Attributes as A


indicator : List (Html.Attribute msg) -> String -> Html msg
indicator attrs label =
    Html.span (attrs ++ [ A.class "da-activity" ])
        [ Html.span [ A.class "da-activity__spinner", A.attribute "aria-hidden" "true" ] []
        , Html.span [] [ Html.text label ]
        ]


view : List (Html.Attribute msg) -> String -> Html msg
view attrs label =
    indicator (attrs ++ [ A.attribute "role" "status", A.attribute "aria-atomic" "true" ]) label
