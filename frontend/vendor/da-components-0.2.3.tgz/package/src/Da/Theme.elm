module Da.Theme exposing (Mode(..), root, accent)

{-| Scoped light, dark, and system themes. Persistence and startup choice belong
to the application. Load styles/da-components.css once per document.

@docs Mode, root, accent

-}

import Char
import Html exposing (Html)
import Html.Attributes as A


type Mode
    = Light
    | Dark
    | System


root : Mode -> List (Html.Attribute msg) -> List (Html msg) -> Html msg
root mode attrs children =
    Html.div
        (attrs
            ++ [ A.class "da-ui"
               , A.attribute "data-da-theme"
                    (case mode of
                        Light ->
                            "light"

                        Dark ->
                            "dark"

                        System ->
                            "system"
                    )
               ]
        )
        children


{-| Set one accent color on a themed root. Accepts #RGB or #RRGGBB, with optional
surrounding whitespace. Selects black or white foreground text by WCAG contrast.
Invalid colors return no overrides, keeping the theme defaults.

    Theme.root Theme.System (Theme.accent "#6750a4") [ appView ]

Focus and subtle selected-state fills derive from the accent in CSS. Put any
explicit style-attribute overrides after these attributes. This helper owns the
root style attribute; use CSS for other root styling. The application owns persistence.

-}
accent : String -> List (Html.Attribute msg)
accent color =
    normalize color
        |> Maybe.map
            (\hex ->
                let
                    channel offset =
                        String.slice offset (offset + 2) hex
                            |> String.toList
                            |> List.foldl (\char total -> total * 16 + digit char) 0
                            |> toFloat
                            |> (\value -> value / 255)
                            |> (\value ->
                                    if value <= 0.04045 then
                                        value / 12.92

                                    else
                                        ((value + 0.055) / 1.055) ^ 2.4
                               )

                    luminance =
                        0.2126 * channel 0 + 0.7152 * channel 2 + 0.0722 * channel 4

                    foreground =
                        if 1.05 / (luminance + 0.05) >= (luminance + 0.05) / 0.05 then
                            "#ffffff"

                        else
                            "#000000"
                in
                [ A.attribute "style" ("--da-accent: #" ++ hex ++ "; --da-on-accent: " ++ foreground ++ ";") ]
            )
        |> Maybe.withDefault []


normalize : String -> Maybe String
normalize color =
    case String.uncons (String.toLower (String.trim color)) of
        Just ( '#', hex ) ->
            if not (String.all (\char -> String.contains (String.fromChar char) "0123456789abcdef") hex) then
                Nothing

            else if String.length hex == 6 then
                Just hex

            else if String.length hex == 3 then
                Just (String.toList hex |> List.concatMap (\char -> [ char, char ]) |> String.fromList)

            else
                Nothing

        _ ->
            Nothing


digit : Char -> Int
digit char =
    if Char.toCode char <= Char.toCode '9' then
        Char.toCode char - Char.toCode '0'

    else
        Char.toCode char - Char.toCode 'a' + 10
