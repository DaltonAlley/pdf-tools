module Da.Internal.Overlay exposing (Config, attributes, config, trigger)

import Da.Button as Button
import Html exposing (Html)
import Html.Attributes as A
import Html.Events as E
import Json.Decode as D


type alias Config msg =
    { id : String, label : String, anchorId : String, open : Bool, onClose : msg }


config : String -> String -> String -> msg -> Config msg
config id label anchorId onClose =
    { id = id, label = label, anchorId = anchorId, open = False, onClose = onClose }


attributes : String -> Config msg -> List (Html.Attribute msg)
attributes kind settings =
    [ A.id settings.id
    , A.class ("da-overlay da-" ++ kind)
    , A.attribute "popover" "manual"
    , A.attribute "data-da-overlay" kind
    , A.attribute "data-da-open"
        (if settings.open then
            "true"

         else
            "false"
        )
    , A.attribute "data-da-anchor" settings.anchorId
    , A.attribute "aria-label" settings.label
    , E.on "da-close" (D.succeed settings.onClose)
    ]


trigger : String -> List (Html.Attribute msg) -> Config msg -> String -> msg -> Html msg
trigger kind attrs settings label onToggle =
    Button.view
        (attrs
            ++ [ A.id settings.anchorId
               , A.attribute "aria-controls" settings.id
               , A.attribute "aria-expanded"
                    (if settings.open then
                        "true"

                     else
                        "false"
                    )
               ]
            ++ (if kind == "menu" then
                    [ A.attribute "aria-haspopup" "menu" ]

                else
                    []
               )
        )
        Button.defaults
        label
        onToggle
