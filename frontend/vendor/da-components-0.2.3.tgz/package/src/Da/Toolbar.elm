module Da.Toolbar exposing (view, group)

{-| Wrapping workspace action groups. Uses role=group and ordinary Tab order;
does not impose the composite ARIA toolbar keyboard model on native fields.

@docs view, group

-}

import Html exposing (Html)
import Html.Attributes as A


view : List (Html.Attribute msg) -> String -> List (Html msg) -> Html msg
view attrs label children =
    Html.div (attrs ++ [ A.class "da-toolbar", A.attribute "role" "group", A.attribute "aria-label" label ]) children


group : List (Html.Attribute msg) -> String -> List (Html msg) -> Html msg
group attrs label children =
    Html.div (attrs ++ [ A.class "da-toolbar__group", A.attribute "role" "group", A.attribute "aria-label" label ]) children
