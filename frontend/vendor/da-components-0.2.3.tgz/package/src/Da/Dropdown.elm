module Da.Dropdown exposing (Option, State, Change, Control, initial, view, subscriptions, reveal)

{-| A styled, select-only combobox. The app owns the selected value and one State
per instance. Handle every Change, wire subscriptions, and call reveal after a
change to keep keyboard navigation visible in a scrolling list.

Use document-unique Field.Config IDs and unique option values. This component
uses the same field label, help, error, orientation, and disabled conventions.
It emits controlled values; it does not serialize a native form value.

@docs Option, State, Change, Control, initial, view, subscriptions, reveal

-}

import Browser.Dom
import Browser.Events
import Da.Field as Field
import Html exposing (Html)
import Html.Attributes as A
import Html.Events as E
import Json.Decode as D
import Task


type alias Option =
    Field.SelectOption


type State
    = State { open : Bool, active : Int, prefix : String, typedAt : Float }


type alias Change =
    { state : State, value : String }


type alias Control msg =
    { value : String, state : State, options : List Option, onChange : Change -> msg }


initial : State
initial =
    State { open = False, active = -1, prefix = "", typedAt = 0 }


enabled : Control msg -> List ( Int, Option )
enabled control =
    control.options |> List.indexedMap Tuple.pair |> List.filter (not << .disabled << Tuple.second)


activeIndex : Control msg -> Int
activeIndex control =
    let
        (State state) =
            control.state

        available =
            enabled control

        selected =
            available |> List.filter (\( _, option ) -> option.value == control.value) |> List.head
    in
    (if state.open then
        available |> List.filter (\( index, _ ) -> index == state.active) |> List.head

     else
        selected
    )
        |> Maybe.map Tuple.first
        |> Maybe.withDefault (selected |> Maybe.map Tuple.first |> Maybe.withDefault (available |> List.head |> Maybe.map Tuple.first |> Maybe.withDefault -1))


close : Bool -> Control msg -> Change
close commit control =
    { state = initial
    , value =
        if commit then
            enabled control |> List.filter (\( index, _ ) -> index == activeIndex control) |> List.head |> Maybe.map (Tuple.second >> .value) |> Maybe.withDefault control.value

        else
            control.value
    }


openAt : Int -> Control msg -> Change
openAt index control =
    { state = State { open = True, active = index, prefix = "", typedAt = 0 }, value = control.value }


keyDecoder : Control msg -> D.Decoder ( msg, Bool )
keyDecoder control =
    D.map5 (\key alt ctrl meta time -> ( key, alt, ( ctrl || meta, time ) ))
        (D.field "key" D.string)
        (D.oneOf [ D.field "altKey" D.bool, D.succeed False ])
        (D.oneOf [ D.field "ctrlKey" D.bool, D.succeed False ])
        (D.oneOf [ D.field "metaKey" D.bool, D.succeed False ])
        (D.oneOf [ D.field "timeStamp" D.float, D.succeed 0 ])
        |> D.andThen
            (\( key, alt, ( modified, time ) ) ->
                let
                    (State state) =
                        control.state

                    available =
                        enabled control

                    position =
                        available |> List.indexedMap (\index ( optionIndex, _ ) -> ( index, optionIndex )) |> List.filter (\( _, optionIndex ) -> optionIndex == activeIndex control) |> List.head |> Maybe.map Tuple.first |> Maybe.withDefault 0

                    at index =
                        available |> List.drop (clamp 0 (max 0 (List.length available - 1)) index) |> List.head |> Maybe.map Tuple.first |> Maybe.withDefault -1

                    result change prevent =
                        D.succeed ( control.onChange change, prevent )

                    move amount =
                        result
                            (openAt
                                (if state.open then
                                    at (position + amount)

                                 else
                                    activeIndex control
                                )
                                control
                            )
                            True

                    letter =
                        String.toLower key

                    prefix =
                        if time - state.typedAt > 500 || String.all (\char -> String.fromChar char == letter) state.prefix then
                            letter

                        else
                            state.prefix ++ letter

                    start =
                        if String.length prefix == 1 then
                            position + 1

                        else
                            position

                    matches =
                        (List.drop start available ++ List.take start available)
                            |> List.filter (\( _, option ) -> String.startsWith prefix (String.toLower option.label))
                            |> List.head
                in
                if modified || List.isEmpty available then
                    D.fail "Not dropdown navigation"

                else
                    case key of
                        "ArrowDown" ->
                            move 1

                        "ArrowUp" ->
                            if alt && state.open then
                                result (close True control) True

                            else
                                move -1

                        "Home" ->
                            result (openAt (at 0) control) True

                        "End" ->
                            result (openAt (at (List.length available - 1)) control) True

                        "PageDown" ->
                            move 10

                        "PageUp" ->
                            move -10

                        "Enter" ->
                            result
                                (if state.open then
                                    close True control

                                 else
                                    openAt (activeIndex control) control
                                )
                                True

                        " " ->
                            result
                                (if state.open then
                                    close True control

                                 else
                                    openAt (activeIndex control) control
                                )
                                True

                        "Escape" ->
                            if state.open then
                                result (close False control) True

                            else
                                D.fail "Already closed"

                        "Tab" ->
                            if state.open then
                                result (close True control) False

                            else
                                D.fail "Native tab navigation"

                        _ ->
                            if String.length key == 1 && not alt then
                                result
                                    { value = control.value
                                    , state = State { open = True, active = matches |> Maybe.map Tuple.first |> Maybe.withDefault (activeIndex control), prefix = prefix, typedAt = time }
                                    }
                                    True

                            else
                                D.fail "Not dropdown navigation"
            )


{-| Subscribe only for an open instance. Outside clicks commit the active option
and dismiss the list. No document listeners exist while the dropdown is closed.
-}
subscriptions : Field.Config -> Control msg -> Sub msg
subscriptions settings control =
    let
        (State state) =
            control.state

        inside =
            ancestor (settings.id ++ "-dropdown")
    in
    if state.open && not settings.disabled && not (List.isEmpty (enabled control)) then
        Browser.Events.onClick
            (D.field "target" inside
                |> D.andThen
                    (\contained ->
                        if contained then
                            D.fail "Inside dropdown"

                        else
                            D.succeed (control.onChange (close True control))
                    )
            )

    else
        Sub.none


ancestor : String -> D.Decoder Bool
ancestor id =
    D.oneOf
        [ D.field "id" D.string
            |> D.andThen
                (\found ->
                    if found == id then
                        D.succeed True

                    else
                        D.field "parentElement" (D.lazy (\_ -> ancestor id))
                )
        , D.succeed False
        ]


optionId : String -> Int -> String
optionId id index =
    id ++ "-option-" ++ String.fromInt index


{-| Call after applying Change.state and Change.value. DOM focus stays on the
trigger; this scrolls the list and, if needed, the page to reveal its active option.
-}
reveal : String -> Control msg -> (Result Browser.Dom.Error () -> msg) -> Cmd msg
reveal id control onResult =
    let
        (State state) =
            control.state

        listId =
            id ++ "-listbox"
    in
    if state.open && activeIndex control >= 0 then
        Task.map3 (\list option viewport -> ( list, option, viewport ))
            (Browser.Dom.getElement listId)
            (Browser.Dom.getElement (optionId id (activeIndex control)))
            (Browser.Dom.getViewportOf listId)
            |> Task.andThen
                (\( list, option, viewport ) ->
                    let
                        top =
                            option.element.y - list.element.y

                        delta =
                            if top < 0 then
                                top

                            else
                                max 0 (top + option.element.height - viewport.viewport.height)
                    in
                    Browser.Dom.setViewportOf listId viewport.viewport.x (viewport.viewport.y + delta)
                )
            |> Task.andThen (\_ -> revealInWindow (optionId id (activeIndex control)))
            |> Task.attempt onResult

    else
        Cmd.none


revealInWindow : String -> Task.Task Browser.Dom.Error ()
revealInWindow id =
    Task.map2 Tuple.pair (Browser.Dom.getElement id) Browser.Dom.getViewport
        |> Task.andThen
            (\( option, viewport ) ->
                let
                    bottom =
                        option.element.y + option.element.height

                    target =
                        if option.element.y < viewport.viewport.y then
                            Just (option.element.y - 8)

                        else if bottom > viewport.viewport.y + viewport.viewport.height then
                            Just (bottom - viewport.viewport.height + 8)

                        else
                            Nothing
                in
                if option.element.height <= 0 then
                    -- A rapid dismissal may hide the list before this task runs.
                    Task.succeed ()

                else
                    case target of
                        Just y ->
                            Browser.Dom.setViewport viewport.viewport.x (max 0 y)

                        Nothing ->
                            Task.succeed ()
            )


view : List (Html.Attribute msg) -> Field.Config -> Control msg -> Html msg
view attrs settings control =
    let
        (State state) =
            control.state

        unavailable =
            settings.disabled || List.isEmpty (enabled control)

        expanded =
            state.open && not unavailable

        bool value =
            if value then
                "true"

            else
                "false"

        labelId =
            settings.id ++ "-label"

        described =
            (if settings.description /= Nothing then
                [ settings.id ++ "-help" ]

             else
                []
            )
                ++ (if settings.error /= Nothing then
                        [ settings.id ++ "-error" ]

                    else
                        []
                   )

        messages =
            (settings.description |> Maybe.map (\help -> [ Html.p [ A.id (settings.id ++ "-help"), A.class "da-field__help" ] [ Html.text help ] ]) |> Maybe.withDefault [])
                ++ (settings.error |> Maybe.map (\error -> [ Html.p [ A.id (settings.id ++ "-error"), A.class "da-field__error" ] [ Html.text error ] ]) |> Maybe.withDefault [])

        orientation =
            case settings.orientation of
                Field.Vertical ->
                    "da-field--vertical"

                Field.Horizontal ->
                    "da-field--horizontal"

                Field.Responsive ->
                    "da-field--responsive"

        selected =
            control.options |> List.filter (\option -> option.value == control.value) |> List.head |> Maybe.map .label |> Maybe.withDefault "Choose an option"
    in
    Html.div [ A.id (settings.id ++ "-dropdown"), A.class ("da-field da-field--surface da-dropdown " ++ orientation) ]
        [ Html.label [ A.id labelId, A.for settings.id, A.class "da-field__label" ]
            ([ Html.text settings.label ]
                ++ (if settings.required then
                        [ Html.span [ A.class "da-field__required" ] [ Html.text " (required)" ] ]

                    else
                        []
                   )
            )
        , Html.div [ A.class "da-field__content" ]
            (Html.button
                (attrs
                    ++ [ A.id settings.id
                       , A.type_ "button"
                       , A.class "da-dropdown__trigger"
                       , A.disabled unavailable
                       , A.attribute "role" "combobox"
                       , A.attribute "aria-haspopup" "listbox"
                       , A.attribute "aria-expanded" (bool expanded)
                       , A.attribute "aria-controls" (settings.id ++ "-listbox")
                       , A.attribute "aria-labelledby" labelId
                       , A.attribute "aria-required" (bool settings.required)
                       , A.attribute "aria-invalid" (bool (settings.error /= Nothing))
                       ]
                    ++ (if List.isEmpty described then
                            []

                        else
                            [ A.attribute "aria-describedby" (String.join " " described) ]
                       )
                    ++ (if expanded then
                            [ A.attribute "aria-activedescendant" (optionId settings.id (activeIndex control)) ]

                        else
                            []
                       )
                    ++ (if unavailable then
                            []

                        else
                            [ E.onClick
                                (control.onChange
                                    (if expanded then
                                        close False control

                                     else
                                        openAt (activeIndex control) control
                                    )
                                )
                            , E.custom "keydown" (D.map (\( message, prevent ) -> { message = message, stopPropagation = True, preventDefault = prevent }) (keyDecoder control))
                            , E.onBlur
                                (control.onChange
                                    (if expanded then
                                        close True control

                                     else
                                        close False control
                                    )
                                )
                            ]
                       )
                )
                [ Html.span [ A.class "da-dropdown__value" ] [ Html.text selected ], Html.span [ A.class "da-dropdown__chevron", A.attribute "aria-hidden" "true" ] [] ]
                :: messages
            )
        , Html.div [ A.id (settings.id ++ "-listbox"), A.class "da-dropdown__list", A.attribute "role" "listbox", A.attribute "aria-labelledby" labelId, A.hidden (not expanded) ]
            (List.indexedMap
                (\index option ->
                    Html.div
                        ([ A.id (optionId settings.id index)
                         , A.class "da-dropdown__option"
                         , A.attribute "role" "option"
                         , A.attribute "aria-selected" (bool (option.value == control.value))
                         , A.attribute "aria-disabled" (bool option.disabled)
                         , A.attribute "data-da-active" (bool (index == activeIndex control))
                         ]
                            ++ (if unavailable then
                                    []

                                else
                                    [ E.preventDefaultOn "mousedown"
                                        (D.succeed
                                            ( control.onChange
                                                { value = control.value
                                                , state =
                                                    if option.disabled then
                                                        control.state

                                                    else
                                                        State { state | active = index }
                                                }
                                            , True
                                            )
                                        )
                                    ]
                                        ++ (if option.disabled then
                                                []

                                            else
                                                [ E.onClick (control.onChange { value = option.value, state = initial }) ]
                                           )
                               )
                        )
                        [ Html.span [] [ Html.text option.label ]
                        , Html.span [ A.class "da-dropdown__check", A.attribute "aria-hidden" "true", A.hidden (option.value /= control.value) ] [ Html.text "✓" ]
                        ]
                )
                control.options
            )
        ]
