module Da.Button exposing (Appearance, Variant(..), defaults, primary, quiet, danger, view, content, icon, submit, submitContent, link, linkContent)

{-| Native actions, explicit submit buttons, and navigation links.

@docs Appearance, Variant, defaults, primary, quiet, danger, view, content, icon, submit, submitContent, link, linkContent

-}

import Html exposing (Html)
import Html.Attributes as A
import Html.Events as E


type Variant
    = Primary
    | Secondary
    | Quiet
    | Danger


type alias Appearance =
    { variant : Variant, disabled : Bool, busy : Bool, className : String }


defaults : Appearance
defaults =
    { variant = Secondary, disabled = False, busy = False, className = "" }


primary : Appearance
primary =
    { defaults | variant = Primary }


quiet : Appearance
quiet =
    { defaults | variant = Quiet }


danger : Appearance
danger =
    { defaults | variant = Danger }


variantClass : Variant -> String
variantClass variant =
    case variant of
        Primary ->
            "da-button--primary"

        Secondary ->
            "da-button--secondary"

        Quiet ->
            "da-button--quiet"

        Danger ->
            "da-button--danger"


attributes : Appearance -> List (Html.Attribute msg)
attributes appearance =
    [ A.class ("da-button " ++ variantClass appearance.variant ++ " " ++ appearance.className)
    , A.disabled (appearance.disabled || appearance.busy)
    , A.attribute "aria-busy"
        (if appearance.busy then
            "true"

         else
            "false"
        )
    ]


{-| An action button never submits its surrounding form. Busy actions retain
their label and dimensions; supply a meaningful label such as "Saving…".
-}
view : List (Html.Attribute msg) -> Appearance -> String -> msg -> Html msg
view attrs appearance label onPress =
    content attrs appearance [ Html.text label ] onPress


{-| Content may include decorative icons and visible text. Keep interactive
elements outside the button. The caller supplies the accessible name through
visible text or attributes.
-}
content : List (Html.Attribute msg) -> Appearance -> List (Html msg) -> msg -> Html msg
content attrs appearance children onPress =
    Html.button (attrs ++ attributes appearance ++ [ A.type_ "button", E.onClick onPress ]) children


{-| An icon-only action requires an explicit accessible label. The supplied
graphic is decorative and excluded from the accessible name.
-}
icon : List (Html.Attribute msg) -> Appearance -> String -> Html msg -> msg -> Html msg
icon attrs appearance label graphic onPress =
    Html.button
        (attrs ++ attributes appearance ++ [ A.class ("da-button da-button--icon " ++ variantClass appearance.variant ++ " " ++ appearance.className), A.type_ "button", A.attribute "aria-label" label, E.onClick onPress ])
        [ Html.span [ A.attribute "aria-hidden" "true" ] [ graphic ] ]


{-| Submits through the containing form's handler. No click handler is added.
-}
submit : List (Html.Attribute msg) -> Appearance -> String -> Html msg
submit attrs appearance label =
    submitContent attrs appearance [ Html.text label ]


submitContent : List (Html.Attribute msg) -> Appearance -> List (Html msg) -> Html msg
submitContent attrs appearance children =
    Html.button (attrs ++ attributes appearance ++ [ A.type_ "submit" ]) children


{-| Navigation retains native link behavior. Links are not disabled buttons.
-}
link : List (Html.Attribute msg) -> Variant -> { label : String, href : String } -> Html msg
link attrs variant config =
    linkContent attrs variant config.href [ Html.text config.label ]


linkContent : List (Html.Attribute msg) -> Variant -> String -> List (Html msg) -> Html msg
linkContent attrs variant href children =
    Html.a (attrs ++ [ A.class ("da-button " ++ variantClass variant), A.href href ]) children
