module Da.Popover exposing (Config, config, trigger, view)

{-| An anchored, nonmodal surface for fields or other ordinary content.
Requires the opt-in browser adapter. Tab uses normal document order. Escape,
outside clicks, and leaving the surface request onClose; handle it in the app.
Keep anchor and surface mounted. IDs must be document-unique.

@docs Config, config, trigger, view

-}

import Da.Internal.Overlay as Overlay
import Html exposing (Html)
import Html.Attributes as A


type alias Config msg =
    Overlay.Config msg


config : String -> String -> String -> msg -> Config msg
config =
    Overlay.config


trigger : List (Html.Attribute msg) -> Config msg -> String -> msg -> Html msg
trigger =
    Overlay.trigger "popover"


view : List (Html.Attribute msg) -> Config msg -> List (Html msg) -> Html msg
view attrs settings children =
    Html.div (attrs ++ Overlay.attributes "popover" settings ++ [ A.attribute "role" "region", A.tabindex -1 ]) children
